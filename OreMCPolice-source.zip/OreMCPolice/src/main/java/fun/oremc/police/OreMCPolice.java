package fun.oremc.police;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class OreMCPolice extends JavaPlugin implements Listener {
    private final List<String> completed = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        completed.addAll(getConfig().getStringList("completed-players"));
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("OreMC Police enabled. First-time players will be asked to reconnect once.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String uuid = player.getUniqueId().toString();

        // Returning players, including players who have already completed this check, are untouched.
        if (completed.contains(uuid)) return;

        for (String line : getConfig().getStringList("messages.chat")) {
            player.sendMessage(color(line));
        }

        String title = getConfig().getString("messages.title", "&b&lOREMC POLICE");
        String subtitle = getConfig().getString("messages.subtitle", "&7Security check in progress...");
        player.sendTitle(color(title), color(subtitle), 5, 40, 10);

        long delay = Math.max(1L, getConfig().getLong("delay-seconds", 3L)) * 20L;
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;

                // Save before disconnecting, so the reconnect is not checked again.
                completed.add(uuid);
                getConfig().set("completed-players", completed);
                saveConfig();

                List<String> lines = getConfig().getStringList("messages.disconnect");
                String reason = String.join("\n", lines.stream().map(OreMCPolice.this::color).toList());
                player.kickPlayer(reason);
            }
        }.runTaskLater(this, delay);
    }

    private String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input);
    }
}
