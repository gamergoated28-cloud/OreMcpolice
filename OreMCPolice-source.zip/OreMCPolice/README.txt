OreMCPolice 1.0.0

Behaviour:
- Only UUIDs not already stored in config.yml receive the check.
- On their first join, they see the OreMC Police chat/title messages.
- After delay-seconds (default 3), they are disconnected with the configured
  "CHECK COMPLETED - Please rejoin" message.
- Their UUID is saved before disconnecting, so the next join is normal.
- If they leave before the timer ends, they are not marked complete and will
  see the check again on their next join.

Build:
1. Install JDK 21+ and Gradle 8+.
2. Open this folder in Gradle or run: gradle build
3. The plugin JAR will be in build/libs/OreMCPolice-1.0.0.jar

Install:
1. Put the JAR in the server's plugins folder.
2. Restart the server.
3. Edit plugins/OreMCPolice/config.yml if desired, then restart.

Compatibility target: Paper 1.21.x. The project compiles against Paper API
1.21.11 and targets Java 21 bytecode. Test on a backup/staging server first.

Note: This is a reconnect notice, not anti-bot verification. It does not
inspect or prove that a player is human. Players are deliberately disconnected
once after their first join, with a clear message explaining why.
